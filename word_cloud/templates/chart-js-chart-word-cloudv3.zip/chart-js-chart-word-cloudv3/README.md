# Chart.js Chart Word Cloud - v3

A Pen created on CodePen.io. Original URL: [https://codepen.io/sgratzl/pen/WNwzYgy](https://codepen.io/sgratzl/pen/WNwzYgy).

